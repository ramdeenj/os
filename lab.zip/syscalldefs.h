#pragma once

//for testing
#define SYSCALL_TEST    1

//I/O
#define SYSCALL_OPEN    2
#define SYSCALL_CLOSE   3
#define SYSCALL_READ    4
#define SYSCALL_WRITE   5
#define SYSCALL_SEEK    6