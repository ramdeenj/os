#pragma once

#include "interrupt.h"

void syscall_handler(struct InterruptContext* ctx);