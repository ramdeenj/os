# pragma once
// Takes a string and copies it to another
void kstrcpy(char* d, char* s);