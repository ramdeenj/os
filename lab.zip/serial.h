#pragma once

void serial_init();
void serial_putc(char ch);
void serial_puts(const char* str); 
