#pragma once
// Takes a string, returns if it is the same as another
int kstrequal(const char* a, const char* b);