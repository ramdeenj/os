
#include "libc/printf.h"
#include "libc/sleep.h"
int main(){
    while(1){
        sleep(1000);
        printf("B");
    }
}
