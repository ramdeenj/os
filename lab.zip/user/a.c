
#include "libc/printf.h"
#include "libc/sleep.h"
int main(){
    while(1){
        sleep(500);
        printf("A");
    }
}
