
#include "libc/printf.h"
#include "libc/sleep.h"
int main(){
    while(1){
        sleep(2000);
        printf("C");
    }
}
