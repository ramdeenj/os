#pragma once

#include "../../syscalldefs.h"

int do_syscall(int req, unsigned p1, unsigned p2, unsigned p3);
