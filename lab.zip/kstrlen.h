#pragma once
// Takes a string and returns the length of it
unsigned kstrlen(const char* s);