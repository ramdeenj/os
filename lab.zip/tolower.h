#pragma once
char tolower(char c);