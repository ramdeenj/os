#pragma once

typedef int ptrdiff_t;
