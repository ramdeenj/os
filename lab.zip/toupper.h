#pragma once
// Takes a upper case letter and return it as a lower character
char toupper(char u);